﻿using System;
using System.Collections.Generic;
//using System.Runtime.InteropServices;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
//using System.Windows;



public partial class _Default : System.Web.UI.Page
{
    //global variables
    static int timeLeft = 61;

    //rick dialogue
    static string dial0 = "Hey Morty. I need some uhhhh help with a project. Don't get too excited. Put your answers in the box over on the right Morty.";
    static string dial1 = "OK Morty, first thing is... First thing is we need some OXYGEN. We're not gonna get very far if we can't breathe Morty. Tell me the ATOMIC NUMBER I need. That's the one at the TOP-LEFT of the element Morty!";
    static string dial2 = "Great. Great job Morty! You did it.... OK, now we need to brighten this place up a bit. It feels a bit... A bit glum Morty. Can you find me the ATOMIC NUMBER for NEON? Hurry, Morty!";
    static string dial3 = "Wow, you took your time huh? It's an... it's an element Morty, we're not looking for anything complicated. Alright now we need some SODIUM. Simple enough. All around us. All the time. Simple. ATOMIC NUMBER.";
    static string dial4 = "Oh biiiiig surprise, you found Sodium! You shouldn't look so smug Morty, as I said it's everywhere... Wait... Quick Morty, we need the CHEMICAL SYMBOL for TUNGSTEN! That's the LETTER IN THE MIDDLE!";
    static string dial5 = "Nice. Now remember that letter Morty and the ones that follow as well... Remember them, cos they're gonna come back. Now track down the SYMBOL for IODINE!";
    static string dial6 = "Alright, we should only need one more... Rhenium Morty! The SYMBOL for RHENIUM... What?! You've never heard of Rhenium?";
    static string dial7 = "OK Morty. Now, just type in the PASSWORD and we're done... You were paying attention right? Don't tell me I brought you all the way here and you can't even remember a couple of letters...";
    static string dial8 = "The password is just putting together the symbols we were looking for... Just put them into the box... MORTY! HURRY!";
    static string dialWin = "You did it Morty! You saved the day! I'd like to say I believed in you the whole time Morty, but let's... let's be real here! I mean, you're not exactly the brightest star in the galaxy...";




    //events
    protected void Page_Load(object sender, EventArgs e)
    {
        buttonRestart.Visible = false;
        imgExplosion.Visible = false;
        gameOver.Visible = false;
        hiddenLabel.Visible = false;



        if (!Page.IsPostBack)
        {
            Session["counter"] = timeLeft;
        }
    }


    protected void gameTimer_Tick(object sender, EventArgs e)
    {
        UpdatePanel1.Update();

        if (textboxAnswer.Text == "")
        {
            textboxAnswer.Focus();
        }

    }

    protected void UpdatePanel1_Load(object sender, EventArgs e)
    {

        if (Session["counter"] != null)
        {

            lblTimeLeft.Text = Convert.ToString(Convert.ToInt16(Session["counter"]) - 1);
        }

        Session["counter"] = Convert.ToString(Convert.ToInt16(Session["counter"]) - 1);


        if (lblRickSpeech.Text == dial7 && Convert.ToInt16(lblTimeLeft.Text) <= 15)
        {
            lblRickSpeech.Text = dial8;
        }

        if (lblRickSpeech.Text == dial0 && Convert.ToInt16(lblTimeLeft.Text) <= 53)
        {
            lblRickSpeech.Text = dial1;
        }

        if (Convert.ToInt16(lblTimeLeft.Text) <= 0)
        {
            UpdatePanel2.Update();
            gameTimer.Enabled = false;
            imgExplosion.Visible = true;
            gameOver.Visible = true;
            imgRick.Visible = false;
            imgSpeechBubble.Visible = false;
            buttonStart.Visible = false;
            lblRickSpeech.Visible = false;
            buttonRestart.Visible = true;
            lblTime1.Visible = false;
            lblTimeLeft.Visible = false;
            buttonAnswer.Visible = false;
            textboxAnswer.Visible = false;
            textboxAnswer.Text = "";

        }
    }

    protected void UpdatePanel2_Load(object sender, EventArgs e)
    {
    }

    protected void buttonStart_Click(object sender, EventArgs e)
    {
        gameTimer.Enabled = true;
        imgSpeechBubble.Visible = true;
        lblRickSpeech.Visible = true;
        lblRickSpeech.Text = dial0;
        lblTime1.Visible = true;
        lblTimeLeft.Visible = true;
        textboxAnswer.Visible = true;
        buttonAnswer.Visible = true;
        buttonAnswer.Text = "Answer";
        buttonStart.Visible = false;
        cover.Visible = false;
        cover2.Visible = false;
        cover3.Visible = false;
        UpdatePanel2.Update();


    }

    protected void buttonRestart_Click(object sender, EventArgs e)
    {
        timeLeft = 61;
        Session["counter"] = timeLeft;
        gameTimer.Enabled = false;
        lblRickSpeech.Visible = false;
        buttonStart.Visible = true;
        imgExplosion.Visible = false;
        gameOver.Visible = false;
        imgRick.Visible = true;
        buttonRestart.Visible = false;
        buttonAnswer.Text = "DO NOT PRESS";
        buttonAnswer.Visible = false;
        textboxAnswer.Visible = false;
        UpdatePanel2.Update();
    }


    protected void buttonAnswer_Click(object sender, EventArgs e)
    {
        if (textboxAnswer.Text == "8")
        {
            timeLeft = 61;
            Session["counter"] = timeLeft;
            lblRickSpeech.Text = dial2;
            gameTimer.Enabled = false;
            gameTimer.Enabled = true;
            textboxAnswer.Text = "";
        }


        else if (textboxAnswer.Text == "10")
        {
            timeLeft = 61;
            Session["counter"] = timeLeft;
            lblRickSpeech.Text = dial3;
            gameTimer.Enabled = false;
            gameTimer.Enabled = true;
            textboxAnswer.Text = "";
        }

        else if (textboxAnswer.Text == "11")
        {
            timeLeft = 61;
            Session["counter"] = timeLeft;
            lblRickSpeech.Text = dial4;
            gameTimer.Enabled = false;
            gameTimer.Enabled = true;
            textboxAnswer.Text = "";
        }

        else if (textboxAnswer.Text.ToUpper() == "W")
        {
            timeLeft = 61;
            Session["counter"] = timeLeft;
            lblRickSpeech.Text = dial5;
            gameTimer.Enabled = false;
            gameTimer.Enabled = true;
            textboxAnswer.Text = "";
        }

        else if (textboxAnswer.Text.ToUpper() == "I")
        {
            timeLeft = 61;
            Session["counter"] = timeLeft;
            lblRickSpeech.Text = dial6;
            gameTimer.Enabled = false;
            gameTimer.Enabled = true;
            textboxAnswer.Text = "";
        }

        else if (textboxAnswer.Text.ToUpper() == "RE")
        {
            timeLeft = 31;
            Session["counter"] = timeLeft;
            lblRickSpeech.Text = dial7;
            gameTimer.Enabled = false;
            gameTimer.Enabled = true;
            textboxAnswer.Text = "";
        }

        else if (textboxAnswer.Text.ToUpper() == "WIRE")
        {
            UpdatePanel1.Update();
            UpdatePanel2.Update();
            timeLeft = 61;
            Session["counter"] = timeLeft;
            lblRickSpeech.Text = dialWin;
            gameTimer.Enabled = false;
            textboxAnswer.Text = "";
            cover.Visible = true;
            buttonStart.Visible = true;
            cover2.Visible = true;
        }

        else
        {
            gameTimer.Enabled = false;
            imgExplosion.Visible = true;
            gameOver.Visible = true;
            imgRick.Visible = false;
            imgSpeechBubble.Visible = false;
            buttonStart.Visible = false;
            lblRickSpeech.Visible = false;
            buttonRestart.Visible = true;
            lblTime1.Visible = false;
            lblTimeLeft.Visible = false;
            textboxAnswer.Visible = false;
            buttonAnswer.Visible = false;
            textboxAnswer.Text = "";
        }
        UpdatePanel1.Update();
    }
}

